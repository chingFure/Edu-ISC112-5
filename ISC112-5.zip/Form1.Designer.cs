﻿namespace _112_5
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            RandBtn = new Button();
            OverRegBtn = new Button();
            ExitBtn = new Button();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // RandBtn
            // 
            RandBtn.Location = new Point(15, 12);
            RandBtn.Margin = new Padding(6);
            RandBtn.Name = "RandBtn";
            RandBtn.Size = new Size(208, 46);
            RandBtn.TabIndex = 0;
            RandBtn.Text = "Random Blocks";
            RandBtn.UseVisualStyleBackColor = true;
            RandBtn.Click += RandBtn_Click;
            // 
            // OverRegBtn
            // 
            OverRegBtn.Location = new Point(241, 12);
            OverRegBtn.Margin = new Padding(6);
            OverRegBtn.Name = "OverRegBtn";
            OverRegBtn.Size = new Size(270, 46);
            OverRegBtn.TabIndex = 1;
            OverRegBtn.Text = "Overlapping Regions";
            OverRegBtn.UseVisualStyleBackColor = true;
            OverRegBtn.Click += OverRegBtn_Click;
            // 
            // ExitBtn
            // 
            ExitBtn.Location = new Point(529, 12);
            ExitBtn.Name = "ExitBtn";
            ExitBtn.Size = new Size(85, 46);
            ExitBtn.TabIndex = 2;
            ExitBtn.Text = "Exit";
            ExitBtn.UseVisualStyleBackColor = true;
            ExitBtn.Click += ExitBtn_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(15, 81);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(600, 400);
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(14F, 30F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(631, 496);
            Controls.Add(pictureBox1);
            Controls.Add(ExitBtn);
            Controls.Add(OverRegBtn);
            Controls.Add(RandBtn);
            Font = new Font("Microsoft JhengHei UI", 18F);
            Margin = new Padding(6);
            Name = "Form1";
            Text = "找出任意區塊間所有重疊區域之系統";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button RandBtn;
        private Button OverRegBtn;
        private Button ExitBtn;
        private PictureBox pictureBox1;
    }
}
